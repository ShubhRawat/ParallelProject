package com.cg.mypaymentapp.service;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.exception.InvalidPhoneNumber;
import com.cg.mypaymentapp.exception.NameException;


public interface WalletService {
	
		public Customer showBalance (String mobileno) throws InvalidPhoneNumber;
		public void fundTransfer (String sourceMobileNo,String targetMobileNo, Double amount) throws InvalidPhoneNumber, InvalidInputException;
		public Customer depositAmount (String mobileNo,Double amount ) throws InvalidInputException;
		public Customer withdrawAmount(String mobileNo, Double amount) throws InvalidPhoneNumber, InvalidInputException;
		public Customer createAccount(Customer customer) throws InvalidInputException;
		
		public boolean validateName(String name) throws NameException;
		
		public boolean validateMobileNo(String mobileNo) throws InvalidPhoneNumber;
		
		public boolean validateAmount(double amount) throws InvalidPhoneNumber, InvalidInputException;

}
