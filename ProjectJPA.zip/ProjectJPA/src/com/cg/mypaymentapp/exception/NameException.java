package com.cg.mypaymentapp.exception;

public class NameException extends Exception{
	public NameException() {
		// TODO Auto-generated constructor stub
		super("Invalid Name declaration...."
				+ "First letter of Name should be capital...:)");
		
	}
}
