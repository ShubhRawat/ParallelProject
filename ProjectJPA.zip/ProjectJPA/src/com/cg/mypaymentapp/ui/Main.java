package com.cg.mypaymentapp.ui;

import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.exception.InvalidPhoneNumber;
import com.cg.mypaymentapp.exception.NameException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Main {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) throws NameException, InvalidPhoneNumber, InvalidInputException {
			// TODO Auto-generated method stub
		
		WalletService service = new WalletServiceImpl();
		Scanner sc = new Scanner(System.in);
		String custName;
		double amount;
		String mobNum;
		Customer customer;
		int ch;
		try{
		do {
				System.out.println("1. Create Customer Acoount ");
				System.out.println("2. Balance show ");
				System.out.println("3. Fund transfer ");
				System.out.println("4. Withdraw ");
				System.out.println("5. Deposit ");
				System.out.println("6. Exit ");
				System.out.print("Enter your choice : ");
				ch = sc.nextInt();
				switch (ch) {
				
				case 1: // create account 
					do{//getting user details
							do{
									System.out.print("Enter customer name : ");
									custName = sc.next();
									if(service.validateName(custName))
											break;
						}while(true);
						
							do{System.out.print("Enter mobile no. : ");
								mobNum = sc.next();
								if(service.validateMobileNo(mobNum))
							break;
						}while(true);
						
						do{
							System.out.print("Enter initial amount : ");
							amount = sc.nextDouble();

						try {
							if(service.validateAmount(amount))
								break;
						} catch (InvalidInputException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						}while(true);
						
					   customer = new Customer();
					
						customer.setName(custName);
						customer.setMobileNo(mobNum);
						customer.setAmount(amount);
						try {
							service.createAccount(customer);
						} catch (InvalidInputException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						System.out.println("Account Created Successfully");
						break;
					}while(true);
					break;
				
				case 2 : // Balance Show
					
						System.out.print(" Enter the customer mobile number : ");
						mobNum = sc.next();
						try{
								if(service.validateMobileNo(mobNum))
							service.showBalance(mobNum);
						}
						catch(InvalidPhoneNumber e)
						{
							System.out.println(e);
						}
						catch(Exception e)
						{System.out.println("Phone Number is not registered");}
						break;
					
				case 3 : // Fund Transfer
						
						
									System.out.print(" Enter the Sender Phone Number : ");
									String mob1 = sc.next();
									try{
										if(!service.validateMobileNo(mob1))
											{
												throw new InvalidPhoneNumber();
											}
										Customer bal = service.showBalance(mob1);
										}
										catch(InvalidPhoneNumber e)
										{
											System.out.println(e);
											break;
										}
										catch(Exception e)
										{System.out.println("Phone Number is not registered");
										break;}
								
									
									
									System.out.print("Enter the Receiver Phone Number : ");
									String mob2 = sc.next();
									try{
										if(!service.validateMobileNo(mob2))
											{
												throw new InvalidPhoneNumber();
											}
										Customer bal = service.showBalance(mob2);
										}
										catch(InvalidPhoneNumber e)
										{
											System.out.println(e);
											break;
										}
										catch(Exception e)
										{System.out.println("Phone Number is not registered");
										break;}
									
									
								System.out.print(" Enter the amount to be transferred : ");
						amount = sc.nextDouble();
					try {
						service.fundTransfer(mob1, mob2, amount);
					} catch (InsufficientBalanceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
						System.out.println(" Transferred Successfully "+amount+" to "+mob2);
						break;
						
				case 4 : // Withdraw Function
					
						System.out.print(" Enter the Customer mobile Number : ");
						mobNum = sc.next();
						System.out.println("Enter the amount to be withdrawn : ");
						amount = sc.nextDouble();
					try {
						service.withdrawAmount(mobNum, amount);
					} catch (InvalidInputException e) {
						
						e.printStackTrace();
					}
						//System.out.println(amount + " Withdrawn \n Balance : " + customer.getAmount());
						break;
						
				case 5 : // Deposit Function
						System.out.println(" Enter the Customer mobile number : ");
						mobNum = sc.next();
						System.out.println(" Enter the amount to be deposited : ");
						amount = sc.nextDouble();
					try {
						service.depositAmount(mobNum, amount);
					} catch (InvalidInputException e) {
						
						e.printStackTrace();
					}
						//System.out.println(amount + " Deposited \n Balance : " + customer.getAmount());
						break;
				}
		}while(ch != 6);
		System.out.println("Program Ended successfully !!!! ");
	}
		catch(Exception e)
		{
			System.out.println("Wrong Choice");
			Main.main(args);
		}
	}

}

