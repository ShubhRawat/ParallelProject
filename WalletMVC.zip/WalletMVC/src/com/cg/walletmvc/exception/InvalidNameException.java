package com.cg.walletmvc.exception;

public class InvalidNameException extends Exception{

	public InvalidNameException() {
		// TODO Auto-generated constructor stub
		super("Invalid Name declaration...."
				+ "First letter of Name should be capital...:)");
		
	}
}
