package com.cg.walletmvc.exception;

public class WalletException extends RuntimeException{
	public WalletException(String message) {
		// TODO Auto-generated constructor stub
		System.out.println(message);
	}

	

}
