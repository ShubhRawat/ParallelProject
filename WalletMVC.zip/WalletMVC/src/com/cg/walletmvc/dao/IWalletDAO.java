package com.cg.walletmvc.dao;

import com.cg.walletmvc.dto.Customer;



public interface IWalletDAO {

	public Customer showBalance (String mobileno);
	
	public Customer updateBalance(String mobNo, Double amount);
	
	public Customer createAccount(Customer customer);
	
	public Customer findAccount(String mobNo);
}
