package com.cg.walletmvc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.walletmvc.dto.Customer;
@Repository("walletdao")
public class IWalletDAOImpl implements IWalletDAO {

	@PersistenceContext
	EntityManager  em;
	
	@Override
	public Customer showBalance(String mobileno) {
		
		 Customer customer = em.find(Customer.class, mobileno);
		return customer;
	}

	@Override
	public Customer updateBalance(String mobNo, Double amount) {
		
		Query sourceQuery = em.createQuery("UPDATE Customer SET amount = :sourcebal where mobile = :sourcemobile");
		sourceQuery.setParameter("sourcebal", amount);
		sourceQuery.setParameter("sourcemobile", mobNo);
		Customer customer = em.find(Customer.class, mobNo);
		return customer;
		
	}

	@Override
	public Customer createAccount(Customer customer) {
		
		em.persist(customer);
		em.flush();
		return customer;
	}

	@Override
	public Customer findAccount(String mobNo) {
		System.out.println("reached here");
		 Customer customer = em.find(Customer.class, mobNo);
		 System.out.println(customer);
			return customer;
	}

}
