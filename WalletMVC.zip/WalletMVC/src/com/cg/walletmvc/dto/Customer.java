package com.cg.walletmvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Customer")
public class Customer {
	
	@Column(name = "cust_name")
	private String name;
	@NotEmpty(message="Name cannot be empty")
	@Id
	@Column(name = "cust_mobno")
	private String mobileNo;
	@NotNull(message="Mobile Number cannot be empty")
	@Column(name = "balance")
	private Double amount;
	
	@Transient
	private String mobileNo2;
	

	public String getMobileNo2() {
		return mobileNo2;
	}






	public void setMobileNo2(String mobileNo2) {
		this.mobileNo2 = mobileNo2;
	}






	public Customer() {
		super();
	}

	

	


	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNo=" + mobileNo
				+ ", amount=" + amount + "]";
	}














	public Customer(String name, String mobileNo, Double amount,
			Double withdrawAmount, Double depositAmount) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.amount = amount;
	
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
}