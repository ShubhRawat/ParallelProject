package com.cg.walletmvc.service;


import com.cg.walletmvc.dto.Customer;
import com.cg.walletmvc.exception.InvalidInputException;
import com.cg.walletmvc.exception.InvalidNameException;
import com.cg.walletmvc.exception.InvalidPhoneNumber;

public interface IWalletService {

	public Customer showBalance (String mobileno) throws InvalidPhoneNumber;
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, Double amount) throws InvalidPhoneNumber, InvalidInputException;
	public Customer depositAmount (String mobileNo,Double amount ) throws InvalidInputException, InvalidPhoneNumber;
	public Customer withdrawAmount(String mobileNo, Double amount) throws InvalidPhoneNumber, InvalidInputException;
	public Customer createAccount(Customer customer) throws InvalidInputException, InvalidPhoneNumber, InvalidNameException;
	
	public boolean validateName(String name) throws InvalidNameException;
	
	public boolean validateMobileNo(String mobileNo) throws InvalidPhoneNumber;
	
	public boolean validateAmount(double amount) throws InvalidPhoneNumber, InvalidInputException;
}
