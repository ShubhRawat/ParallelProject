package com.cg.walletmvc.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.cg.walletmvc.dao.IWalletDAO;
import com.cg.walletmvc.dto.Customer;
import com.cg.walletmvc.exception.InsufficientBalanceException;
import com.cg.walletmvc.exception.InvalidInputException;
import com.cg.walletmvc.exception.InvalidNameException;
import com.cg.walletmvc.exception.InvalidPhoneNumber;

@Service("mobileservice")
@Transactional
public class IWalletServiceIMPL implements IWalletService{

	@Autowired
	IWalletDAO walletdao;
	
	@Override
	public Customer showBalance(String mobileno) throws InvalidPhoneNumber{
		Customer customer = walletdao.showBalance(mobileno);
		System.out.println("Name : " + customer.getName());
		System.out.println("Mobile No : " + customer.getMobileNo());
		System.out.println("Balance : " + customer.getAmount());
		return customer;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			Double amount) throws InvalidInputException,InvalidPhoneNumber {
		
		
		Customer source = walletdao.findAccount(sourceMobileNo);
		Customer target = walletdao.findAccount(targetMobileNo);
		
		try
		{
		if (amount > 0) {
				if((source.getAmount() - amount) >= 0)
				{	
					
						double bal1 = target.getAmount();
						bal1 += amount;
						target.setAmount(bal1);
						walletdao.updateBalance(targetMobileNo, bal1);
						System.out.println("target updated");
						double bal2 = source.getAmount();
						bal2 -= amount;
						source.setAmount(bal2);
						walletdao.updateBalance(sourceMobileNo, bal2);
						System.out.println(target);
				}
				else {
						throw new InsufficientBalanceException("Balance should be higher than amount to be transferred !!!! ");
				}
		}
		else 
				throw new InvalidInputException("Amount should be positive to send");
		}
		catch(Exception e){}
		return target;
	}

	@Override
	public Customer depositAmount(String mobileNo, Double amount) throws InvalidInputException,InvalidPhoneNumber {
		Customer customer = walletdao.findAccount(mobileNo);
		if (amount > 0) {
				double bal = customer.getAmount();
				bal += amount;
				customer.setAmount(bal);
				System.out.println(amount + " Deposited \n Balance : " + customer.getAmount());
				walletdao.updateBalance(mobileNo, bal);
				return customer;
		}
		else 
				throw new InvalidInputException("Amount should be positive");
	}

	@Override
	public Customer withdrawAmount(String mobileNo, Double amount) throws InvalidInputException,InvalidPhoneNumber {
		Customer customer = walletdao.findAccount(mobileNo);
		if(amount > 0) {
				if((customer.getAmount() - amount) >= 0)
				{		
						double bal = customer.getAmount();
						bal -= amount;
						customer.setAmount(bal);
						System.out.println(amount + " Withdrawn \n Balance : " + customer.getAmount());
						walletdao.updateBalance(mobileNo, bal);
						return customer;
				}
				else 
						throw new InsufficientBalanceException("Balance is not sufficient for this withdrawl amount");
		}
		else 
				throw new InvalidInputException("Amount cannot be Negative ");
	}

	@Override
	public Customer createAccount(Customer customer) throws InvalidPhoneNumber,InvalidInputException,InvalidNameException {
	  
		walletdao.createAccount(customer);
		return customer;
	}

	@Override
	public boolean validateName(String name)throws InvalidNameException {
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{2,10}");
		Matcher m = p.matcher(name); 
		if(!m.matches())
			{System.out.println("Name invalid!(Should Start with Capital letter and minimum length should be 3....)");
			System.out.println();
		
			}
		return m.matches();
	}

	@Override
	public boolean validateMobileNo(String mobileNo) throws InvalidPhoneNumber {
		Pattern p = Pattern.compile("[6789][0-9]{9}");
		Matcher m = p.matcher(mobileNo);
		return m.matches();
	}

	@Override
	public boolean validateAmount(double amount) throws InvalidPhoneNumber, InvalidInputException{
		try{
			if(amount == 0)
				throw new InvalidInputException("");
			String am = String.valueOf(amount);
			if(!am.matches("\\d{1,9}\\.\\d{0,4}"))
				System.out.println("Invalid Amount!(Should be greater than 0)");
			else
				return (am.matches("\\d{1,9}\\.\\d{0,4}"));
		}
		catch(InvalidInputException e){
			System.out.println(e);
			
		}
		return false;
	}

}
