package com.cg.walletmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import org.springframework.web.servlet.ModelAndView;

import com.cg.walletmvc.dto.Customer;
import com.cg.walletmvc.exception.InvalidInputException;
import com.cg.walletmvc.exception.InvalidNameException;
import com.cg.walletmvc.exception.InvalidPhoneNumber;
import com.cg.walletmvc.service.IWalletService;

@Controller
public class WalletController {

	@Autowired
	IWalletService walletservice;
	
	//Sending the user to Homepage
	@RequestMapping(value="/homepage")
	public String homePage()
	{
		return "index";
	}
	
	
	
	//Staring of Create New Account Functionality
	
	@RequestMapping(value="/create", method=RequestMethod.GET)
	public String openAccount(@ModelAttribute("yy") Customer cust)
			{
				return "createaccount";
			}
	
	
	@RequestMapping(value="/openaccount", method=RequestMethod.POST)
	public String openNewAccount(@ModelAttribute("yy") Customer cust) throws InvalidInputException,InvalidNameException
	,InvalidPhoneNumber
	{
		walletservice.createAccount(cust);
		return "accountCreatedSuccessfully";
    }
	
	//End of Create New Account Functionality
	
	
	
	//Starting of Check balance functionality 
	
	@RequestMapping(value="/balance", method=RequestMethod.GET)
	public String searchbalance(@ModelAttribute("yy") Customer cust){
		return "fetchBalance";
	}
	
	
	@RequestMapping(value="accountbalance", method=RequestMethod.POST)
	public ModelAndView dataSearch(@ModelAttribute("yy") Customer cust) throws InvalidPhoneNumber
	{
		Customer custSearch=walletservice.showBalance(cust.getMobileNo());
		return new ModelAndView("UserAccountBalance","temp",custSearch);
	}
	
	//End of Check balance functionality
	
	
	//Starting of Withdrawal functionality
	
	@RequestMapping(value="/withdraw", method=RequestMethod.GET)
	public String withdrawFromAccount(@ModelAttribute("yy") Customer cust)
			{
				return "withdrawMoney";
			}
	
	@RequestMapping(value="withdrawfromaccount", method=RequestMethod.POST)
	public ModelAndView withdrawData(@ModelAttribute("yy") Customer cust) throws InvalidPhoneNumber, InvalidInputException
	{
		Customer custSearch=walletservice.withdrawAmount(cust.getMobileNo(), cust.getAmount());
		return new ModelAndView("afterwithdrawl","temp",custSearch);
	}
	
	//End of Withdrawal functionality
	
	
	//Starting of Deposit functionality
	
		@RequestMapping(value="/deposit", method=RequestMethod.GET)
		public String depositToAccount(@ModelAttribute("yy") Customer cust)
				{
					return "depositMoney";
				}
		
		@RequestMapping(value="depsositintoaccount", method=RequestMethod.POST)
		public ModelAndView depositData(@ModelAttribute("yy") Customer cust) throws InvalidPhoneNumber, InvalidInputException
		{
			Customer custSearch=walletservice.depositAmount(cust.getMobileNo(), cust.getAmount());
			return new ModelAndView("afterdeposit","temp",custSearch);
		}
		
		//End of Withdrawal functionality
		
		
		//Starting of Fund Transfer Functionality
		
		@RequestMapping(value="/fundtransfer", method=RequestMethod.GET)
		public String transferToAccount(@ModelAttribute("yy") Customer cust)
				{
					return "transferMoney";
				}
		
		@RequestMapping(value="transfersourcetotarget", method=RequestMethod.POST)
		public ModelAndView transferData(@ModelAttribute("yy") Customer cust) throws InvalidPhoneNumber, InvalidInputException
		{
			Customer custSearch=walletservice.fundTransfer(cust.getMobileNo(), cust.getMobileNo2(),cust.getAmount());
			return new ModelAndView("aftertransfer","temp",custSearch);
		}
		
		//End of Fund Transfer Functionality
	
	
}